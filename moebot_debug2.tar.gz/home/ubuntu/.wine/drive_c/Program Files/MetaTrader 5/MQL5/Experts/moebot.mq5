//+------------------------------------------------------------------+
//|                 MoeBot Hybrid Pro v3.3.1 Fixed Entry Runner |
//|        Classic + ICT + SMC + Memory Retest Trading Engine         |
//|                 Built for DEMO testing on MT5                    |
//+------------------------------------------------------------------+
#property strict
#property version   "3.31"
#property description "MoeBot Hybrid Pro v3.3.1 - v3.3 Base + Late Entry Guard + Profit Follow TP Runner"

#include <Trade/Trade.mqh>
CTrade trade;

//---------------------------- Inputs --------------------------------
input string BotName = "MoeBot Hybrid Pro v3.3.1 Fixed Entry Runner";
input long   MagicNumber = 11062026;

input bool   AllowNewTrades = true;
input bool   OneOpenTradePerSymbol = false;   // false allows Smart Add-On logic
input double FixedLot = 0.01;                  // fallback only

// Symbol-based lot sizing
input bool   UseSymbolLots = true;
input double Lot_Default = 0.01;
input double Lot_XAUUSD = 0.01;
input double Lot_XAGUSD = 0.01;
input double Lot_EURUSD = 0.05;
input double Lot_GBPUSD = 0.05;
input double Lot_USDJPY = 0.05;
input double Lot_AUDUSD = 0.05;
input double Lot_NAS100 = 0.01;
input double Lot_US30 = 0.01;

input bool   UseRiskPercent = false;
input double RiskPercent = 1.0;
input int    SlippagePoints = 30;

// Demo testing mode: no max trades/day, no daily loss stop, no losing trades stop
input int    MinimumScore = 6;
input bool   EvaluateEveryTick = false;
input int    LookbackBars = 350;

input int    EMA_Fast = 50;
input int    EMA_Slow = 200;

input int    RSI_Period = 14;
input double RSI_Buy_Min = 50.0;
input double RSI_Sell_Max = 50.0;
input double RSI_Overbought = 75.0;
input double RSI_Oversold = 25.0;
input bool   RequireRSI = false;

input bool   UseADXFilter = false;
input int    ADX_Period = 14;
input double ADX_Min = 18.0;

input int    MaxSpreadPoints = 500;

input ENUM_TIMEFRAMES BiasTF1 = PERIOD_H1;
input ENUM_TIMEFRAMES BiasTF2 = PERIOD_H4;
input bool   RequireHTFSupport = true;
input bool   AllowStrongICTSMCOverride = true;
input int    StrongOverrideExtraScore = 2;

input int    SwingStrength = 3;
input int    StructureLookback = 180;
input int    SweepLookback = 60;
input int    FVGLookback = 80;

input bool   UseMemoryEngine = true;
input int    StructureMemoryBars = 18;
input int    SweepMemoryBars = 10;
input int    FVGMemoryBars = 24;

input double PullbackBufferATR = 0.45;
input double FVG_Retest_ATR_Tolerance = 0.20;
input double MaxChaseATR = 0.75;

input int    ATR_Period = 14;
input double SL_ATR_Buffer = 0.50;
input double SL_ATR_Fallback = 2.0;
input double RiskReward = 3.0;
input int    MinSLPoints = 50;
input int    MaxSLPoints = 0;

input bool   MoveToBreakEven = true;
input double BreakEvenAtR = 1.0;
input int    BE_BufferPoints = 10;

input bool   EnableTrailingAfterBE = true;
input double Trail_ATR_Multiplier = 1.2;
input int    TrailStepPoints = 50;

// Profit follow: protect profit earlier, then let winners run.
input bool   UseProfitLock = true;
input double ProtectAtR_1 = 0.50;
input double LockProfitR_1 = 0.05;
input double ProtectAtR_2 = 0.75;
input double LockProfitR_2 = 0.25;
input double ProtectAtR_3 = 1.00;
input double LockProfitR_3 = 0.50;

// TP Runner: TP extends only after the position is protected.
input bool   UseTPRunner = true;
input double TPRunnerStartR = 1.20;
input double TPRunnerATRMultiplier = 2.0;
input double TPRunnerMinExtensionATR = 0.25;
input bool   TPRunnerOncePerBar = true;

// Light Late Entry Guard: blocks only obvious exhaustion entries, not normal setups.
input bool   UseLateEntryGuard = true;
input double LateGuardFarEMA_ATR = 2.00;
input double LateGuardFarStructure_ATR = 2.50;
input double LateGuardSellRSI_Max = 35.0;
input double LateGuardBuyRSI_Min = 65.0;

// Smart Add-On / Pyramiding only on winning protected trades. NO Martingale.
input bool   AllowSmartAddOns = true;
input int    MaxPositionsPerSymbol = 2;
input bool   AddOnlySameDirection = true;
input bool   AddOnlyIfCurrentTradeInProfit = true;
input bool   AddOnlyAfterBreakEven = true;
input int    AddMinimumScore = 7;
input double AddLotMultiplier = 0.50;
input double MinAddDistanceATR = 0.80;

// Session filter is kept available, but OFF for demo testing to keep enough trades
input bool   UseSessionFilter = false;
input int    LondonStartHour = 7;
input int    LondonEndHour = 16;
input int    NewYorkStartHour = 13;
input int    NewYorkEndHour = 22;

// Automatic news/spike protection without manual news calendar
input bool   UseNewsSpikeGuard = true;
input bool   UseSpreadSpikeGuard = true;
input double SpikeATRMultiplier = 2.5;
input int    PauseAfterSpikeBars = 4;
input double MaxEntryCandleATR = 1.8;

// Smart early exit: take profit early if market shows strong reversal
input bool   UseSmartEarlyExit = true;
input bool   CloseOnOppositeStrongSignal = true;
input int    OppositeSignalCloseScore = 8;
input bool   OnlyCloseIfInProfit = true;
input double MinimumProfitToEarlyCloseR = 0.70;

input bool   HeavyDebugLogs = false;
input bool   ShortDecisionLogs = true;

//---------------------------- Constants -----------------------------
#define DIR_BUY   1
#define DIR_SELL -1

//---------------------------- Handles -------------------------------
int hEmaFast = INVALID_HANDLE;
int hEmaSlow = INVALID_HANDLE;
int hRSI     = INVALID_HANDLE;
int hADX     = INVALID_HANDLE;
int hATR     = INVALID_HANDLE;
int hH1Fast  = INVALID_HANDLE;
int hH1Slow  = INVALID_HANDLE;
int hH4Fast  = INVALID_HANDLE;
int hH4Slow  = INVALID_HANDLE;

//---------------------------- Signal struct -------------------------
struct Signal
{
   int      dir;
   string   dirText;
   int      score;
   bool     canTrade;
   string   skip;
   string   reason;

   bool     spreadOK;
   double   spreadPts;
   int      h1Bias;
   int      h4Bias;
   bool     htfOK;
   int      emaDir;
   bool     emaOK;
   double   rsi;
   bool     rsiOK;
   double   adx;
   bool     adxOK;

   bool     structure;
   bool     currentStructure;
   bool     memoryStructure;
   double   structureLevel;
   string   structureSource;

   bool     sweep;
   bool     currentSweep;
   bool     memorySweep;
   double   sweepExtreme;
   string   sweepSource;

   bool     fvgRetest;
   bool     currentFVG;
   bool     memoryFVG;
   double   fvgLower;
   double   fvgMid;
   double   fvgUpper;
   string   fvgSource;

   bool     pullbackRetest;
   bool     entryTrigger;
   bool     noChaseOK;

   double   atr;
   double   entry;
   double   sl;
   double   tp;
   double   riskPts;
   bool     isAddOn;
   string   positionReason;
   string   slReason;
   string   tpReason;
};

//---------------------------- Memory --------------------------------
bool   memBuyStruct = false;
double memBuyLevel = 0.0;
int    memBuyStructAge = 999999;
string memBuyStructType = "";

bool   memSellStruct = false;
double memSellLevel = 0.0;
int    memSellStructAge = 999999;
string memSellStructType = "";

bool   memBuySweep = false;
double memBuySweepLow = 0.0;
int    memBuySweepAge = 999999;

bool   memSellSweep = false;
double memSellSweepHigh = 0.0;
int    memSellSweepAge = 999999;

bool   memBuyFVG = false;
double memBuyFvgLower = 0.0;
double memBuyFvgMid = 0.0;
double memBuyFvgUpper = 0.0;
int    memBuyFvgAge = 999999;

bool   memSellFVG = false;
double memSellFvgLower = 0.0;
double memSellFvgMid = 0.0;
double memSellFvgUpper = 0.0;
int    memSellFvgAge = 999999;

int spikePauseBarsRemaining = 0;

//+------------------------------------------------------------------+
//| Utility                                                          |
//+------------------------------------------------------------------+
string B(bool v){ return v ? "YES" : "NO"; }

string DirText(int dir)
{
   if(dir == DIR_BUY)  return "BUY";
   if(dir == DIR_SELL) return "SELL";
   return "NONE";
}

double PointValue(){ return SymbolInfoDouble(_Symbol, SYMBOL_POINT); }
int DigitsValue(){ return (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS); }
double NPrice(double p){ return NormalizeDouble(p, DigitsValue()); }

double Buf(int handle, int buffer, int shift)
{
   if(handle == INVALID_HANDLE) return 0.0;
   double arr[];
   ArraySetAsSeries(arr, true);
   if(CopyBuffer(handle, buffer, shift, 1, arr) <= 0) return 0.0;
   return arr[0];
}

bool IsNewBar()
{
   static datetime lastTime = 0;
   datetime t = iTime(_Symbol, _Period, 0);
   if(t != lastTime)
   {
      lastTime = t;
      return true;
   }
   return false;
}

double NormalizeVolume(double lots)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double stepLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(stepLot <= 0.0) stepLot = 0.01;

   lots = MathMax(minLot, MathMin(maxLot, lots));
   lots = MathFloor(lots / stepLot) * stepLot;
   return NormalizeDouble(lots, 2);
}

string UpperSymbol()
{
   string s = _Symbol;
   StringToUpper(s);
   return s;
}

void LogShort(string msg)
{
   if(ShortDecisionLogs || HeavyDebugLogs)
      Print(msg);
}

double SymbolBaseLot()
{
   if(!UseSymbolLots)
      return FixedLot;

   string s = UpperSymbol();

   if(StringFind(s, "XAU") >= 0 || StringFind(s, "GOLD") >= 0)
      return Lot_XAUUSD;

   if(StringFind(s, "XAG") >= 0 || StringFind(s, "SILVER") >= 0)
      return Lot_XAGUSD;

   if(StringFind(s, "EURUSD") >= 0)
      return Lot_EURUSD;

   if(StringFind(s, "GBPUSD") >= 0)
      return Lot_GBPUSD;

   if(StringFind(s, "USDJPY") >= 0)
      return Lot_USDJPY;

   if(StringFind(s, "AUDUSD") >= 0)
      return Lot_AUDUSD;

   if(StringFind(s, "NAS") >= 0 || StringFind(s, "US100") >= 0 || StringFind(s, "USTEC") >= 0 || StringFind(s, "NQ") >= 0)
      return Lot_NAS100;

   if(StringFind(s, "US30") >= 0 || StringFind(s, "DJ30") >= 0 || StringFind(s, "DOW") >= 0 || StringFind(s, "WS30") >= 0)
      return Lot_US30;

   return Lot_Default;
}

double CalculateLots(double slPoints)
{
   double baseLot = SymbolBaseLot();

   if(!UseRiskPercent) return NormalizeVolume(baseLot);
   if(slPoints <= 0)  return NormalizeVolume(baseLot);

   double balance   = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskMoney = balance * RiskPercent / 100.0;
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double point     = PointValue();

   if(tickValue <= 0 || tickSize <= 0 || point <= 0) return NormalizeVolume(baseLot);

   double valuePerPointPerLot = tickValue * (point / tickSize);
   if(valuePerPointPerLot <= 0) return NormalizeVolume(baseLot);

   return NormalizeVolume(riskMoney / (slPoints * valuePerPointPerLot));
}

bool HasOpenPositionForThisBot()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) == _Symbol && PositionGetInteger(POSITION_MAGIC) == MagicNumber)
         return true;
   }
   return false;
}

int CountBotPositions(int &direction, bool &mixed)
{
   int count = 0;
   direction = 0;
   mixed = false;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int dir = (type == POSITION_TYPE_BUY) ? DIR_BUY : DIR_SELL;

      if(direction == 0) direction = dir;
      else if(direction != dir) mixed = true;

      count++;
   }

   if(mixed) direction = 0;
   return count;
}

bool ExistingPositionsInProfit(int dir)
{
   double totalProfit = 0.0;
   int count = 0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int pdir = (type == POSITION_TYPE_BUY) ? DIR_BUY : DIR_SELL;
      if(pdir != dir) continue;

      totalProfit += PositionGetDouble(POSITION_PROFIT);
      count++;
   }

   return (count > 0 && totalProfit > 0.0);
}

bool ExistingPositionsProtectedAtBE(int dir)
{
   double point = PointValue();
   double slack = MathMax(BE_BufferPoints * point, point * 2);
   int count = 0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int pdir = (type == POSITION_TYPE_BUY) ? DIR_BUY : DIR_SELL;
      if(pdir != dir) continue;

      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      if(sl <= 0.0) return false;

      if(dir == DIR_BUY && sl < openPrice - slack) return false;
      if(dir == DIR_SELL && sl > openPrice + slack) return false;

      count++;
   }

   return (count > 0);
}

double LastEntryPriceForDirection(int dir)
{
   datetime latest = 0;
   double price = 0.0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int pdir = (type == POSITION_TYPE_BUY) ? DIR_BUY : DIR_SELL;
      if(pdir != dir) continue;

      datetime t = (datetime)PositionGetInteger(POSITION_TIME);
      if(t >= latest)
      {
         latest = t;
         price = PositionGetDouble(POSITION_PRICE_OPEN);
      }
   }

   return price;
}

bool SessionAllowed()
{
   if(!UseSessionFilter) return true;

   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   int h = dt.hour;

   bool inLondon = (h >= LondonStartHour && h < LondonEndHour);
   bool inNY     = (h >= NewYorkStartHour && h < NewYorkEndHour);

   return (inLondon || inNY);
}

bool SpikeGuardActive(MqlRates &rates[], int bars, double atr, string &reason)
{
   reason = "";
   if(!UseNewsSpikeGuard && !UseSpreadSpikeGuard) return false;

   double point = PointValue();
   if(point <= 0.0) return false;

   if(UseSpreadSpikeGuard)
   {
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double spreadPts = (ask - bid) / point;
      if(spreadPts > MaxSpreadPoints)
      {
         reason = "Spread spike/high spread: " + DoubleToString(spreadPts, 1);
         return true;
      }
   }

   if(!UseNewsSpikeGuard || atr <= 0.0 || bars < 3) return false;

   if(spikePauseBarsRemaining > 0)
   {
      reason = "Spike pause active. Remaining bars=" + IntegerToString(spikePauseBarsRemaining);
      return true;
   }

   double lastRange = rates[1].high - rates[1].low;
   double rangeATR = lastRange / atr;

   if(rangeATR >= SpikeATRMultiplier)
   {
      spikePauseBarsRemaining = PauseAfterSpikeBars;
      reason = "News/spike candle detected: rangeATR=" + DoubleToString(rangeATR, 2);
      return true;
   }

   if(rangeATR >= MaxEntryCandleATR)
   {
      reason = "Entry blocked after large candle: rangeATR=" + DoubleToString(rangeATR, 2);
      return true;
   }

   return false;
}

bool CanOpenNewOrAddOn(Signal &s, bool &isAddOn, string &blockReason, double &lotMultiplier)
{
   isAddOn = false;
   blockReason = "";
   lotMultiplier = 1.0;

   int direction = 0;
   bool mixed = false;
   int count = CountBotPositions(direction, mixed);

   if(count <= 0)
      return true;

   if(mixed)
   {
      blockReason = "Blocked: mixed/open opposite positions already exist";
      return false;
   }

   if(OneOpenTradePerSymbol && !AllowSmartAddOns)
   {
      blockReason = "Blocked: OneOpenTradePerSymbol active";
      return false;
   }

   if(!AllowSmartAddOns)
   {
      blockReason = "Blocked: Smart Add-On disabled and position exists";
      return false;
   }

   if(count >= MaxPositionsPerSymbol)
   {
      blockReason = "Blocked: MaxPositionsPerSymbol reached";
      return false;
   }

   if(AddOnlySameDirection && direction != s.dir)
   {
      blockReason = "Blocked: existing position is opposite direction";
      return false;
   }

   if(AddOnlyIfCurrentTradeInProfit && !ExistingPositionsInProfit(s.dir))
   {
      blockReason = "Blocked: existing position not in profit";
      return false;
   }

   if(AddOnlyAfterBreakEven && !ExistingPositionsProtectedAtBE(s.dir))
   {
      blockReason = "Blocked: existing position not protected at BE";
      return false;
   }

   if(s.score < AddMinimumScore)
   {
      blockReason = "Blocked: add-on score too low";
      return false;
   }

   double lastEntry = LastEntryPriceForDirection(s.dir);
   if(lastEntry > 0.0 && s.atr > 0.0)
   {
      double dist = MathAbs(s.entry - lastEntry);
      if(dist < s.atr * MinAddDistanceATR)
      {
         blockReason = "Blocked: add-on too close to last entry";
         return false;
      }
   }

   isAddOn = true;
   lotMultiplier = AddLotMultiplier;
   return true;
}

bool CloseProfitablePositionsOnOppositeSignal(int positionDir, Signal &oppositeSignal)
{
   if(!UseSmartEarlyExit || !CloseOnOppositeStrongSignal) return false;
   if(oppositeSignal.score < OppositeSignalCloseScore) return false;
   if(!(oppositeSignal.structure || oppositeSignal.sweep || oppositeSignal.fvgRetest)) return false;

   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   bool closedAny = false;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int pdir = (type == POSITION_TYPE_BUY) ? DIR_BUY : DIR_SELL;
      if(pdir != positionDir) continue;

      double profitMoney = PositionGetDouble(POSITION_PROFIT);
      if(OnlyCloseIfInProfit && profitMoney <= 0.0) continue;

      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      double risk = 0.0;

      if(tp > 0.0 && RiskReward > 0.0)
         risk = MathAbs(tp - openPrice) / RiskReward;
      if(risk <= 0.0 && sl > 0.0)
         risk = MathAbs(openPrice - sl);
      if(risk <= 0.0) continue;

      double profitDistance = (pdir == DIR_BUY) ? (bid - openPrice) : (openPrice - ask);
      double profitR = profitDistance / risk;
      if(profitR < MinimumProfitToEarlyCloseR) continue;

      if(trade.PositionClose(ticket))
      {
         string log = BotName;
         log += " | SMART EARLY EXIT ";
         log += DirText(pdir);
         log += " | Ticket=" + IntegerToString((int)ticket);
         log += " | ProfitR=" + DoubleToString(profitR, 2);
         log += " | OppScore=" + IntegerToString(oppositeSignal.score);
         log += " | Reason=strong opposite signal";
         Print(log);
         closedAny = true;
      }
      else
      {
         Print(BotName + " | SMART EARLY EXIT FAILED | Ticket=" + IntegerToString((int)ticket) + " | Error=" + IntegerToString(GetLastError()));
      }
   }

   return closedAny;
}

//+------------------------------------------------------------------+
//| Bias                                                             |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Bias                                                             |
//+------------------------------------------------------------------+
int HTFBias(int fastHandle, int slowHandle, ENUM_TIMEFRAMES tf)
{
   double fast = Buf(fastHandle, 0, 1);
   double slow = Buf(slowHandle, 0, 1);
   double cls  = iClose(_Symbol, tf, 1);

   if(fast <= 0 || slow <= 0 || cls <= 0) return 0;
   if(fast > slow && cls > slow) return DIR_BUY;
   if(fast < slow && cls < slow) return DIR_SELL;
   return 0;
}

int CurrentEMADir()
{
   double fast = Buf(hEmaFast, 0, 1);
   double slow = Buf(hEmaSlow, 0, 1);
   double cls  = iClose(_Symbol, _Period, 1);

   if(fast <= 0 || slow <= 0 || cls <= 0) return 0;
   if(fast > slow && cls > slow) return DIR_BUY;
   if(fast < slow && cls < slow) return DIR_SELL;
   return 0;
}

//+------------------------------------------------------------------+
//| Swings                                                           |
//+------------------------------------------------------------------+
bool IsSwingHigh(MqlRates &rates[], int bars, int shift)
{
   if(shift - SwingStrength < 1) return false;
   if(shift + SwingStrength >= bars) return false;

   double c = rates[shift].high;
   for(int i = 1; i <= SwingStrength; i++)
   {
      if(c <= rates[shift - i].high) return false;
      if(c <= rates[shift + i].high) return false;
   }
   return true;
}

bool IsSwingLow(MqlRates &rates[], int bars, int shift)
{
   if(shift - SwingStrength < 1) return false;
   if(shift + SwingStrength >= bars) return false;

   double c = rates[shift].low;
   for(int i = 1; i <= SwingStrength; i++)
   {
      if(c >= rates[shift - i].low) return false;
      if(c >= rates[shift + i].low) return false;
   }
   return true;
}

bool FindSwingHigh(MqlRates &rates[], int bars, double &price)
{
   price = 0.0;
   int start = SwingStrength + 1;
   int endShift = MathMin(StructureLookback, bars - SwingStrength - 1);

   for(int shift = start; shift <= endShift; shift++)
   {
      if(IsSwingHigh(rates, bars, shift))
      {
         price = rates[shift].high;
         return true;
      }
   }
   return false;
}

bool FindSwingLow(MqlRates &rates[], int bars, double &price)
{
   price = 0.0;
   int start = SwingStrength + 1;
   int endShift = MathMin(StructureLookback, bars - SwingStrength - 1);

   for(int shift = start; shift <= endShift; shift++)
   {
      if(IsSwingLow(rates, bars, shift))
      {
         price = rates[shift].low;
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| High/Low helpers                                                 |
//+------------------------------------------------------------------+
double HighestHigh(MqlRates &rates[], int bars, int startShift, int count)
{
   if(startShift >= bars) return 0.0;
   double h = rates[startShift].high;
   int endShift = MathMin(startShift + count - 1, bars - 1);
   for(int i = startShift; i <= endShift; i++)
      if(rates[i].high > h) h = rates[i].high;
   return h;
}

double LowestLow(MqlRates &rates[], int bars, int startShift, int count)
{
   if(startShift >= bars) return 0.0;
   double l = rates[startShift].low;
   int endShift = MathMin(startShift + count - 1, bars - 1);
   for(int i = startShift; i <= endShift; i++)
      if(rates[i].low < l) l = rates[i].low;
   return l;
}

//+------------------------------------------------------------------+
//| FVG helpers                                                      |
//+------------------------------------------------------------------+
bool FindFVG(MqlRates &rates[], int bars, int dir, double &lower, double &mid, double &upper)
{
   lower = 0.0; mid = 0.0; upper = 0.0;
   int maxShift = MathMin(FVGLookback, bars - 4);

   for(int i = 1; i <= maxShift; i++)
   {
      int older = i + 2;
      if(older >= bars) break;

      if(dir == DIR_BUY)
      {
         if(rates[i].low > rates[older].high)
         {
            lower = rates[older].high;
            upper = rates[i].low;
            mid = (lower + upper) / 2.0;
            return true;
         }
      }

      if(dir == DIR_SELL)
      {
         if(rates[i].high < rates[older].low)
         {
            lower = rates[i].high;
            upper = rates[older].low;
            mid = (lower + upper) / 2.0;
            return true;
         }
      }
   }
   return false;
}

bool FVGRetest(int dir, double price, double atr, double lower, double mid, double upper)
{
   if(atr <= 0 || lower <= 0 || upper <= 0 || mid <= 0) return false;
   double tol = atr * FVG_Retest_ATR_Tolerance;

   if(dir == DIR_BUY)
      return (price <= mid + tol && price >= lower - tol);

   if(dir == DIR_SELL)
      return (price >= mid - tol && price <= upper + tol);

   return false;
}

//+------------------------------------------------------------------+
//| Memory                                                           |
//+------------------------------------------------------------------+
void AgeMemory()
{
   if(!UseMemoryEngine) return;

   if(memBuyStruct)  memBuyStructAge++;
   if(memSellStruct) memSellStructAge++;
   if(memBuySweep)   memBuySweepAge++;
   if(memSellSweep)  memSellSweepAge++;
   if(memBuyFVG)     memBuyFvgAge++;
   if(memSellFVG)    memSellFvgAge++;

   if(memBuyStructAge  > StructureMemoryBars) memBuyStruct = false;
   if(memSellStructAge > StructureMemoryBars) memSellStruct = false;
   if(memBuySweepAge   > SweepMemoryBars)     memBuySweep = false;
   if(memSellSweepAge  > SweepMemoryBars)     memSellSweep = false;
   if(memBuyFvgAge     > FVGMemoryBars)       memBuyFVG = false;
   if(memSellFvgAge    > FVGMemoryBars)       memSellFVG = false;
}

void ResetDirectionMemory(int dir)
{
   if(dir == DIR_BUY)
   {
      memBuyStruct = false;
      memBuySweep = false;
      memBuyFVG = false;
   }
   if(dir == DIR_SELL)
   {
      memSellStruct = false;
      memSellSweep = false;
      memSellFVG = false;
   }
}

void PrintMemory()
{
   if(!HeavyDebugLogs || !UseMemoryEngine) return;

   string log = BotName;
   log += " | MEMORY";
   log += " | BuyStruct=" + B(memBuyStruct) + " level=" + DoubleToString(memBuyLevel, DigitsValue()) + " age=" + IntegerToString(memBuyStructAge);
   log += " | SellStruct=" + B(memSellStruct) + " level=" + DoubleToString(memSellLevel, DigitsValue()) + " age=" + IntegerToString(memSellStructAge);
   log += " | BuySweep=" + B(memBuySweep) + " low=" + DoubleToString(memBuySweepLow, DigitsValue()) + " age=" + IntegerToString(memBuySweepAge);
   log += " | SellSweep=" + B(memSellSweep) + " high=" + DoubleToString(memSellSweepHigh, DigitsValue()) + " age=" + IntegerToString(memSellSweepAge);
   log += " | BuyFVG=" + B(memBuyFVG) + " age=" + IntegerToString(memBuyFvgAge);
   log += " | SellFVG=" + B(memSellFVG) + " age=" + IntegerToString(memSellFvgAge);
   Print(log);
}

//+------------------------------------------------------------------+
//| Signal initialization                                            |
//+------------------------------------------------------------------+
void InitSignal(Signal &s, int dir)
{
   s.dir = dir;
   s.dirText = DirText(dir);
   s.score = 0;
   s.canTrade = false;
   s.skip = "";
   s.reason = "";

   s.spreadOK = false;
   s.spreadPts = 0.0;
   s.h1Bias = 0;
   s.h4Bias = 0;
   s.htfOK = false;
   s.emaDir = 0;
   s.emaOK = false;
   s.rsi = 0.0;
   s.rsiOK = false;
   s.adx = 0.0;
   s.adxOK = false;

   s.structure = false;
   s.currentStructure = false;
   s.memoryStructure = false;
   s.structureLevel = 0.0;
   s.structureSource = "";

   s.sweep = false;
   s.currentSweep = false;
   s.memorySweep = false;
   s.sweepExtreme = 0.0;
   s.sweepSource = "";

   s.fvgRetest = false;
   s.currentFVG = false;
   s.memoryFVG = false;
   s.fvgLower = 0.0;
   s.fvgMid = 0.0;
   s.fvgUpper = 0.0;
   s.fvgSource = "";

   s.pullbackRetest = false;
   s.entryTrigger = false;
   s.noChaseOK = true;

   s.atr = 0.0;
   s.entry = 0.0;
   s.sl = 0.0;
   s.tp = 0.0;
   s.riskPts = 0.0;
   s.isAddOn = false;
   s.positionReason = "";
   s.slReason = "";
   s.tpReason = "";
}

//+------------------------------------------------------------------+
//| Build SL/TP                                                      |
//+------------------------------------------------------------------+
bool BuildSLTP(Signal &s, bool swingHighFound, double swingHigh, bool swingLowFound, double swingLow)
{
   double point = PointValue();
   if(point <= 0 || s.atr <= 0) return false;

   double minDist = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * point;
   if(minDist < point * 2) minDist = point * 2;

   double buffer = s.atr * SL_ATR_Buffer;

   if(s.dir == DIR_BUY)
   {
      double baseLow = 0.0;
      if(s.sweep && s.sweepExtreme > 0)
      {
         baseLow = s.sweepExtreme;
         s.slReason = "SL below liquidity sweep low + ATR buffer";
      }
      else if(swingLowFound)
      {
         baseLow = swingLow;
         s.slReason = "SL below recent swing low + ATR buffer";
      }
      else
      {
         baseLow = s.entry - s.atr * SL_ATR_Fallback;
         s.slReason = "Fallback SL using ATR";
      }

      s.sl = NPrice(baseLow - buffer);
      if(s.entry - s.sl < minDist) s.sl = NPrice(s.entry - minDist);

      double risk = s.entry - s.sl;
      if(risk <= 0) return false;

      s.tp = NPrice(s.entry + risk * RiskReward);
      s.riskPts = risk / point;
      s.tpReason = "TP based on RR=" + DoubleToString(RiskReward, 2) + "R";
   }

   if(s.dir == DIR_SELL)
   {
      double baseHigh = 0.0;
      if(s.sweep && s.sweepExtreme > 0)
      {
         baseHigh = s.sweepExtreme;
         s.slReason = "SL above liquidity sweep high + ATR buffer";
      }
      else if(swingHighFound)
      {
         baseHigh = swingHigh;
         s.slReason = "SL above recent swing high + ATR buffer";
      }
      else
      {
         baseHigh = s.entry + s.atr * SL_ATR_Fallback;
         s.slReason = "Fallback SL using ATR";
      }

      s.sl = NPrice(baseHigh + buffer);
      if(s.sl - s.entry < minDist) s.sl = NPrice(s.entry + minDist);

      double risk = s.sl - s.entry;
      if(risk <= 0) return false;

      s.tp = NPrice(s.entry - risk * RiskReward);
      s.riskPts = risk / point;
      s.tpReason = "TP based on RR=" + DoubleToString(RiskReward, 2) + "R";
   }

   if(s.riskPts < MinSLPoints)
   {
      s.skip = "SL too tight: " + DoubleToString(s.riskPts, 1) + " < MinSLPoints";
      return false;
   }

   if(MaxSLPoints > 0 && s.riskPts > MaxSLPoints)
   {
      s.skip = "SL too wide: " + DoubleToString(s.riskPts, 1) + " > MaxSLPoints";
      return false;
   }

   return true;
}


//+------------------------------------------------------------------+
//| Entry guard and runner helpers                                   |
//+------------------------------------------------------------------+
string TicketRiskKey(ulong ticket)
{
   return BotName + "_RISK_" + IntegerToString((int)MagicNumber) + "_" + _Symbol + "_" + IntegerToString((int)ticket);
}

string TicketTPBarKey(ulong ticket)
{
   return BotName + "_TPBAR_" + IntegerToString((int)MagicNumber) + "_" + _Symbol + "_" + IntegerToString((int)ticket);
}

double GetInitialRisk(ulong ticket, ENUM_POSITION_TYPE type, double openPrice, double sl, double tp)
{
   string key = TicketRiskKey(ticket);
   if(GlobalVariableCheck(key))
   {
      double saved = GlobalVariableGet(key);
      if(saved > 0.0) return saved;
   }

   double risk = 0.0;

   if(type == POSITION_TYPE_BUY)
   {
      if(sl > 0.0 && sl < openPrice) risk = openPrice - sl;
      if(risk <= 0.0 && tp > openPrice && RiskReward > 0.0) risk = (tp - openPrice) / RiskReward;
   }
   else
   {
      if(sl > openPrice) risk = sl - openPrice;
      if(risk <= 0.0 && tp > 0.0 && tp < openPrice && RiskReward > 0.0) risk = (openPrice - tp) / RiskReward;
   }

   if(risk > 0.0)
      GlobalVariableSet(key, risk);

   return risk;
}

bool IsPositionProtected(ENUM_POSITION_TYPE type, double openPrice, double sl)
{
   double point = PointValue();
   double slack = MathMax(BE_BufferPoints * point, point * 2);
   if(sl <= 0.0) return false;
   if(type == POSITION_TYPE_BUY)  return (sl >= openPrice - slack);
   if(type == POSITION_TYPE_SELL) return (sl <= openPrice + slack);
   return false;
}

bool TPAlreadyExtendedThisBar(ulong ticket)
{
   if(!TPRunnerOncePerBar) return false;
   string key = TicketTPBarKey(ticket);
   datetime barTime = iTime(_Symbol, _Period, 0);
   if(GlobalVariableCheck(key) && (datetime)GlobalVariableGet(key) == barTime)
      return true;
   return false;
}

void MarkTPExtendedThisBar(ulong ticket)
{
   if(!TPRunnerOncePerBar) return;
   string key = TicketTPBarKey(ticket);
   datetime barTime = iTime(_Symbol, _Period, 0);
   GlobalVariableSet(key, (double)barTime);
}

bool LateEntryGuardBlocks(Signal &s, string &reason)
{
   reason = "";
   if(!UseLateEntryGuard) return false;
   if(s.atr <= 0.0) return false;

   // Fresh BOS / current sweep is allowed. The guard only blocks stale late-continuation entries.
   if(s.currentStructure || s.currentSweep)
      return false;

   double emaFast = Buf(hEmaFast, 0, 1);
   if(emaFast <= 0.0) return false;

   double distEMA_ATR = MathAbs(s.entry - emaFast) / s.atr;
   double distStruct_ATR = 0.0;
   if(s.structureLevel > 0.0)
      distStruct_ATR = MathAbs(s.entry - s.structureLevel) / s.atr;

   bool farFromEMA = (distEMA_ATR >= LateGuardFarEMA_ATR);
   bool farFromStructure = (distStruct_ATR >= LateGuardFarStructure_ATR || (s.memoryStructure && !s.currentStructure));

   if(s.dir == DIR_SELL)
   {
      bool exhaustedSell = (s.rsi > 0.0 && s.rsi <= LateGuardSellRSI_Max);
      if(farFromEMA && farFromStructure && exhaustedSell)
      {
         reason = "Late Entry Guard blocked SELL: far from EMA + stale continuation + RSI oversold | DistEMA_ATR=" + DoubleToString(distEMA_ATR, 2) + " | DistStruct_ATR=" + DoubleToString(distStruct_ATR, 2) + " | RSI=" + DoubleToString(s.rsi, 2);
         return true;
      }
   }

   if(s.dir == DIR_BUY)
   {
      bool exhaustedBuy = (s.rsi >= LateGuardBuyRSI_Min);
      if(farFromEMA && farFromStructure && exhaustedBuy)
      {
         reason = "Late Entry Guard blocked BUY: far from EMA + stale continuation + RSI overbought | DistEMA_ATR=" + DoubleToString(distEMA_ATR, 2) + " | DistStruct_ATR=" + DoubleToString(distStruct_ATR, 2) + " | RSI=" + DoubleToString(s.rsi, 2);
         return true;
      }
   }

   return false;
}

//+------------------------------------------------------------------+
//| Build Signal                                                     |
//+------------------------------------------------------------------+
Signal BuildSignal(
   int dir,
   bool currStruct,
   double currStructLevel,
   string currStructName,
   bool currSweep,
   double currSweepExtreme,
   bool currFVG,
   double currFvgLower,
   double currFvgMid,
   double currFvgUpper,
   bool swingHighFound,
   double swingHigh,
   bool swingLowFound,
   double swingLow
)
{
   Signal s;
   InitSignal(s, dir);

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double point = PointValue();

   if(point <= 0 || ask <= 0 || bid <= 0)
   {
      s.skip = "Invalid price or point";
      return s;
   }

   s.entry = (dir == DIR_BUY) ? ask : bid;
   s.spreadPts = (ask - bid) / point;
   s.spreadOK = (s.spreadPts <= MaxSpreadPoints);

   if(!s.spreadOK)
   {
      s.skip = "Spread too high: " + DoubleToString(s.spreadPts, 1);
      return s;
   }

   s.atr = Buf(hATR, 0, 1);
   if(s.atr <= 0)
   {
      s.skip = "ATR unavailable";
      return s;
   }

   s.h1Bias = HTFBias(hH1Fast, hH1Slow, BiasTF1);
   s.h4Bias = HTFBias(hH4Fast, hH4Slow, BiasTF2);

   if(s.h1Bias == dir) s.score += 2;
   else if(s.h1Bias == -dir) s.score -= 1;

   if(s.h4Bias == dir) s.score += 2;
   else if(s.h4Bias == -dir) s.score -= 1;

   s.emaDir = CurrentEMADir();
   s.emaOK = (s.emaDir == dir);
   if(s.emaOK) s.score += 1;
   else if(s.emaDir == -dir) s.score -= 1;

   s.rsi = Buf(hRSI, 0, 1);
   if(dir == DIR_BUY)
      s.rsiOK = (s.rsi >= RSI_Buy_Min && s.rsi <= RSI_Overbought);
   else
      s.rsiOK = (s.rsi <= RSI_Sell_Max && s.rsi >= RSI_Oversold);

   if(s.rsiOK) s.score += 1;

   if(UseADXFilter)
   {
      s.adx = Buf(hADX, 0, 1);
      s.adxOK = (s.adx >= ADX_Min);
      if(s.adxOK) s.score += 1;
   }
   else
   {
      s.adx = 0.0;
      s.adxOK = true;
   }

   if(currStruct)
   {
      s.structure = true;
      s.currentStructure = true;
      s.structureLevel = currStructLevel;
      s.structureSource = currStructName;
      s.score += 2;
   }
   else if(UseMemoryEngine)
   {
      if(dir == DIR_BUY && memBuyStruct)
      {
         s.structure = true;
         s.memoryStructure = true;
         s.structureLevel = memBuyLevel;
         s.structureSource = memBuyStructType + " age=" + IntegerToString(memBuyStructAge);
         s.score += 2;
      }
      if(dir == DIR_SELL && memSellStruct)
      {
         s.structure = true;
         s.memoryStructure = true;
         s.structureLevel = memSellLevel;
         s.structureSource = memSellStructType + " age=" + IntegerToString(memSellStructAge);
         s.score += 2;
      }
   }

   if(currSweep)
   {
      s.sweep = true;
      s.currentSweep = true;
      s.sweepExtreme = currSweepExtreme;
      s.sweepSource = (dir == DIR_BUY) ? "Current sell-side liquidity sweep" : "Current buy-side liquidity sweep";
      s.score += 3;
   }
   else if(UseMemoryEngine)
   {
      if(dir == DIR_BUY && memBuySweep)
      {
         s.sweep = true;
         s.memorySweep = true;
         s.sweepExtreme = memBuySweepLow;
         s.sweepSource = "Memory sell-side liquidity sweep age=" + IntegerToString(memBuySweepAge);
         s.score += 3;
      }
      if(dir == DIR_SELL && memSellSweep)
      {
         s.sweep = true;
         s.memorySweep = true;
         s.sweepExtreme = memSellSweepHigh;
         s.sweepSource = "Memory buy-side liquidity sweep age=" + IntegerToString(memSellSweepAge);
         s.score += 3;
      }
   }

   if(currFVG && FVGRetest(dir, s.entry, s.atr, currFvgLower, currFvgMid, currFvgUpper))
   {
      s.fvgRetest = true;
      s.currentFVG = true;
      s.fvgLower = currFvgLower;
      s.fvgMid = currFvgMid;
      s.fvgUpper = currFvgUpper;
      s.fvgSource = "Current FVG retest";
      s.score += 3;
   }
   else if(UseMemoryEngine)
   {
      if(dir == DIR_BUY && memBuyFVG && FVGRetest(dir, s.entry, s.atr, memBuyFvgLower, memBuyFvgMid, memBuyFvgUpper))
      {
         s.fvgRetest = true;
         s.memoryFVG = true;
         s.fvgLower = memBuyFvgLower;
         s.fvgMid = memBuyFvgMid;
         s.fvgUpper = memBuyFvgUpper;
         s.fvgSource = "Memory bullish FVG age=" + IntegerToString(memBuyFvgAge);
         s.score += 3;
      }
      if(dir == DIR_SELL && memSellFVG && FVGRetest(dir, s.entry, s.atr, memSellFvgLower, memSellFvgMid, memSellFvgUpper))
      {
         s.fvgRetest = true;
         s.memoryFVG = true;
         s.fvgLower = memSellFvgLower;
         s.fvgMid = memSellFvgMid;
         s.fvgUpper = memSellFvgUpper;
         s.fvgSource = "Memory bearish FVG age=" + IntegerToString(memSellFvgAge);
         s.score += 3;
      }
   }

   if(s.structure && s.structureLevel > 0)
   {
      double dist = MathAbs(s.entry - s.structureLevel);
      if(dist <= s.atr * PullbackBufferATR)
      {
         s.pullbackRetest = true;
         s.score += 2;
      }
   }

   s.entryTrigger = (s.sweep || s.fvgRetest || s.pullbackRetest);

   if(s.structure && !s.entryTrigger)
      s.noChaseOK = false;

   if(s.structure && !s.sweep && !s.fvgRetest && s.structureLevel > 0)
   {
      double chaseDist = MathAbs(s.entry - s.structureLevel);
      if(chaseDist > s.atr * MaxChaseATR)
         s.noChaseOK = false;
   }

   bool hasHTFSupport = (s.h1Bias == dir || s.h4Bias == dir);
   bool bothHTFOppose = (s.h1Bias == -dir && s.h4Bias == -dir);

   bool strongOverride = false;
   if(AllowStrongICTSMCOverride)
   {
      if(s.score >= MinimumScore + StrongOverrideExtraScore && s.structure && s.sweep && s.fvgRetest)
         strongOverride = true;
   }

   if(!RequireHTFSupport) s.htfOK = true;
   else s.htfOK = (hasHTFSupport && !bothHTFOppose) || strongOverride;

   if(!s.htfOK)
   {
      s.skip = "HTF bias does not support trade";
      return s;
   }

   if(RequireRSI && !s.rsiOK)
   {
      s.skip = "RSI confirmation failed";
      return s;
   }

   if(UseADXFilter && !s.adxOK)
   {
      s.skip = "ADX below minimum";
      return s;
   }

   if(!s.structure && !(s.sweep && s.fvgRetest))
   {
      s.skip = "No structure and no strong sweep+FVG setup";
      return s;
   }

   if(!s.entryTrigger)
   {
      s.skip = "No retest/sweep/FVG trigger";
      return s;
   }

   if(!s.noChaseOK)
   {
      s.skip = "No-chase filter blocked entry";
      return s;
   }

   if(s.score < MinimumScore)
   {
      s.skip = "Score too low: " + IntegerToString(s.score) + " < " + IntegerToString(MinimumScore);
      return s;
   }

   string lateGuardReason = "";
   if(LateEntryGuardBlocks(s, lateGuardReason))
   {
      s.skip = lateGuardReason;
      return s;
   }

   if(!BuildSLTP(s, swingHighFound, swingHigh, swingLowFound, swingLow))
   {
      if(s.skip == "") s.skip = "Invalid SL/TP";
      return s;
   }

   s.canTrade = true;

   if(s.h1Bias == dir) s.reason += "H1 bias + ";
   if(s.h4Bias == dir) s.reason += "H4 bias + ";
   if(s.emaOK) s.reason += "EMA + ";
   if(s.structure) s.reason += "Structure + ";
   if(s.sweep) s.reason += "Sweep + ";
   if(s.fvgRetest) s.reason += "FVG Retest + ";
   if(s.pullbackRetest) s.reason += "Pullback + ";
   if(s.rsiOK) s.reason += "RSI + ";
   if(UseADXFilter && s.adxOK) s.reason += "ADX + ";

   return s;
}

//+------------------------------------------------------------------+
//| Debug                                                            |
//+------------------------------------------------------------------+
void PrintSignal(Signal &s)
{
   if(!HeavyDebugLogs) return;

   string log = BotName;
   log += " | Symbol=" + _Symbol;
   log += " | TF=" + EnumToString(_Period);
   log += " | Dir=" + s.dirText;
   log += " | Score=" + IntegerToString(s.score);
   log += " | CanTrade=" + B(s.canTrade);
   log += " | Spread=" + DoubleToString(s.spreadPts, 1);
   log += " | H1=" + DirText(s.h1Bias);
   log += " | H4=" + DirText(s.h4Bias);
   log += " | HTF_OK=" + B(s.htfOK);
   log += " | EMA=" + DirText(s.emaDir);
   log += " | RSI=" + DoubleToString(s.rsi, 2) + " RSI_OK=" + B(s.rsiOK);
   log += " | ADX=" + DoubleToString(s.adx, 2) + " ADX_OK=" + B(s.adxOK);
   log += " | Structure=" + B(s.structure) + " src=" + s.structureSource + " lvl=" + DoubleToString(s.structureLevel, DigitsValue());
   log += " | Sweep=" + B(s.sweep) + " src=" + s.sweepSource + " ext=" + DoubleToString(s.sweepExtreme, DigitsValue());
   log += " | FVG_Retest=" + B(s.fvgRetest) + " src=" + s.fvgSource;
   log += " | Pullback=" + B(s.pullbackRetest);
   log += " | Trigger=" + B(s.entryTrigger);
   log += " | NoChase=" + B(s.noChaseOK);
   log += " | Entry=" + DoubleToString(s.entry, DigitsValue());
   log += " | SL=" + DoubleToString(s.sl, DigitsValue());
   log += " | TP=" + DoubleToString(s.tp, DigitsValue());
   log += " | RiskPts=" + DoubleToString(s.riskPts, 1);
   log += " | Reason=" + s.reason;
   log += " | Skip=" + s.skip;

   Print(log);
}

//+------------------------------------------------------------------+
//| Execute trade                                                    |
//+------------------------------------------------------------------+
void ExecuteTrade(Signal &s)
{
   if(!AllowNewTrades)
   {
      LogShort(BotName + " | New trades disabled");
      return;
   }

   bool isAddOn = false;
   string blockReason = "";
   double lotMultiplier = 1.0;
   if(!CanOpenNewOrAddOn(s, isAddOn, blockReason, lotMultiplier))
   {
      LogShort(BotName + " | " + s.dirText + " skipped | " + blockReason + " | Score=" + IntegerToString(s.score));
      return;
   }

   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
   {
      Print(BotName + " | Terminal trading not allowed");
      return;
   }

   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
   {
      Print(BotName + " | EA trading not allowed. Check Algo Trading button");
      return;
   }

   double lots = CalculateLots(s.riskPts);
   if(isAddOn)
      lots = NormalizeVolume(lots * lotMultiplier);

   s.isAddOn = isAddOn;
   s.positionReason = isAddOn ? "SMART_ADDON" : "NEW_ENTRY";

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   bool ok = false;
   string comment = isAddOn ? ("MoeBot Hybrid v3.3.1 ADD " + s.dirText) : ("MoeBot Hybrid v3.3.1 " + s.dirText);

   if(s.dir == DIR_BUY)
      ok = trade.Buy(lots, _Symbol, 0.0, s.sl, s.tp, comment);
   else
      ok = trade.Sell(lots, _Symbol, 0.0, s.sl, s.tp, comment);

   if(ok)
   {
      string log = BotName;
      log += " | ORDER SENT " + s.dirText;
      log += isAddOn ? " | SMART_ADDON" : " | NEW_ENTRY";
      log += " | Symbol=" + _Symbol;
      log += " | Lots=" + DoubleToString(lots, 2);
      log += " | Entry=" + DoubleToString(s.entry, DigitsValue());
      log += " | SL=" + DoubleToString(s.sl, DigitsValue());
      log += " | TP=" + DoubleToString(s.tp, DigitsValue());
      log += " | Score=" + IntegerToString(s.score);
      log += " | RR=" + DoubleToString(RiskReward, 2);
      log += " | Reason=" + s.reason;
      Print(log);
      ResetDirectionMemory(s.dir);
   }
   else
   {
      string log = BotName;
      log += " | ORDER FAILED " + s.dirText;
      log += " | Retcode=" + IntegerToString((int)trade.ResultRetcode());
      log += " | Desc=" + trade.ResultRetcodeDescription();
      log += " | Error=" + IntegerToString(GetLastError());
      Print(log);
   }
}

//+------------------------------------------------------------------+
//| Manage positions                                                 |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Manage positions                                                 |
//+------------------------------------------------------------------+
void ManageOpenPositions()
{
   double point = PointValue();
   if(point <= 0) return;

   double atr = Buf(hATR, 0, 1);
   if(atr <= 0) return;

   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

   double minDist = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * point;
   if(minDist < point * 2) minDist = point * 2;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      long magic = PositionGetInteger(POSITION_MAGIC);
      if(sym != _Symbol || magic != MagicNumber) continue;

      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      if(sl <= 0.0) continue;

      double initialRisk = GetInitialRisk(ticket, type, openPrice, sl, tp);
      if(initialRisk <= 0.0) continue;

      trade.SetExpertMagicNumber(MagicNumber);
      trade.SetDeviationInPoints(SlippagePoints);

      if(type == POSITION_TYPE_BUY)
      {
         double profitR = (bid - openPrice) / initialRisk;
         double desiredSL = sl;

         if(UseProfitLock)
         {
            double lockR = -1.0;
            if(profitR >= ProtectAtR_3) lockR = LockProfitR_3;
            else if(profitR >= ProtectAtR_2) lockR = LockProfitR_2;
            else if(profitR >= ProtectAtR_1) lockR = LockProfitR_1;

            if(lockR >= 0.0)
            {
               double lockSL = NPrice(openPrice + initialRisk * lockR);
               if(lockSL > desiredSL) desiredSL = lockSL;
            }
         }

         if(MoveToBreakEven && profitR >= BreakEvenAtR)
         {
            double beSL = NPrice(openPrice + BE_BufferPoints * point);
            if(beSL > desiredSL) desiredSL = beSL;
         }

         if(desiredSL > sl && desiredSL < bid - minDist)
         {
            if(trade.PositionModify(ticket, desiredSL, tp))
            {
               Print(BotName + " | ProfitLock/BE BUY | Ticket=" + IntegerToString((int)ticket) + " | ProfitR=" + DoubleToString(profitR, 2) + " | NewSL=" + DoubleToString(desiredSL, DigitsValue()));
               sl = desiredSL;
            }
         }

         if(EnableTrailingAfterBE && IsPositionProtected(type, openPrice, sl))
         {
            double trailSL = NPrice(bid - atr * Trail_ATR_Multiplier);
            if(trailSL > sl + TrailStepPoints * point && trailSL < bid - minDist)
            {
               if(trade.PositionModify(ticket, trailSL, tp))
               {
                  Print(BotName + " | Trailing BUY | Ticket=" + IntegerToString((int)ticket) + " | NewSL=" + DoubleToString(trailSL, DigitsValue()));
                  sl = trailSL;
               }
            }
         }

         if(UseTPRunner && IsPositionProtected(type, openPrice, sl) && profitR >= TPRunnerStartR && !TPAlreadyExtendedThisBar(ticket))
         {
            double proposedTP = NPrice(bid + atr * TPRunnerATRMultiplier);
            double minExtension = atr * TPRunnerMinExtensionATR;
            if(tp <= 0.0 || proposedTP > tp + minExtension)
            {
               if(proposedTP > bid + minDist)
               {
                  if(trade.PositionModify(ticket, sl, proposedTP))
                  {
                     MarkTPExtendedThisBar(ticket);
                     Print(BotName + " | TP RUNNER BUY | Ticket=" + IntegerToString((int)ticket) + " | ProfitR=" + DoubleToString(profitR, 2) + " | OldTP=" + DoubleToString(tp, DigitsValue()) + " | NewTP=" + DoubleToString(proposedTP, DigitsValue()));
                  }
               }
            }
         }
      }

      if(type == POSITION_TYPE_SELL)
      {
         double profitR = (openPrice - ask) / initialRisk;
         double desiredSL = sl;

         if(UseProfitLock)
         {
            double lockR = -1.0;
            if(profitR >= ProtectAtR_3) lockR = LockProfitR_3;
            else if(profitR >= ProtectAtR_2) lockR = LockProfitR_2;
            else if(profitR >= ProtectAtR_1) lockR = LockProfitR_1;

            if(lockR >= 0.0)
            {
               double lockSL = NPrice(openPrice - initialRisk * lockR);
               if(lockSL < desiredSL) desiredSL = lockSL;
            }
         }

         if(MoveToBreakEven && profitR >= BreakEvenAtR)
         {
            double beSL = NPrice(openPrice - BE_BufferPoints * point);
            if(beSL < desiredSL) desiredSL = beSL;
         }

         if(desiredSL < sl && desiredSL > ask + minDist)
         {
            if(trade.PositionModify(ticket, desiredSL, tp))
            {
               Print(BotName + " | ProfitLock/BE SELL | Ticket=" + IntegerToString((int)ticket) + " | ProfitR=" + DoubleToString(profitR, 2) + " | NewSL=" + DoubleToString(desiredSL, DigitsValue()));
               sl = desiredSL;
            }
         }

         if(EnableTrailingAfterBE && IsPositionProtected(type, openPrice, sl))
         {
            double trailSL = NPrice(ask + atr * Trail_ATR_Multiplier);
            if(trailSL < sl - TrailStepPoints * point && trailSL > ask + minDist)
            {
               if(trade.PositionModify(ticket, trailSL, tp))
               {
                  Print(BotName + " | Trailing SELL | Ticket=" + IntegerToString((int)ticket) + " | NewSL=" + DoubleToString(trailSL, DigitsValue()));
                  sl = trailSL;
               }
            }
         }

         if(UseTPRunner && IsPositionProtected(type, openPrice, sl) && profitR >= TPRunnerStartR && !TPAlreadyExtendedThisBar(ticket))
         {
            double proposedTP = NPrice(ask - atr * TPRunnerATRMultiplier);
            double minExtension = atr * TPRunnerMinExtensionATR;
            if(tp <= 0.0 || proposedTP < tp - minExtension)
            {
               if(proposedTP < ask - minDist)
               {
                  if(trade.PositionModify(ticket, sl, proposedTP))
                  {
                     MarkTPExtendedThisBar(ticket);
                     Print(BotName + " | TP RUNNER SELL | Ticket=" + IntegerToString((int)ticket) + " | ProfitR=" + DoubleToString(profitR, 2) + " | OldTP=" + DoubleToString(tp, DigitsValue()) + " | NewTP=" + DoubleToString(proposedTP, DigitsValue()));
                  }
               }
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Evaluate signals                                                 |
//+------------------------------------------------------------------+
void EvaluateSignals()
{
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   int copied = CopyRates(_Symbol, _Period, 0, LookbackBars, rates);

   if(copied < MathMax(EMA_Slow + 20, 250))
   {
      Print(BotName + " | Not enough bars. Copied=" + IntegerToString(copied));
      return;
   }

   int bars = copied;
   AgeMemory();

   if(spikePauseBarsRemaining > 0)
      spikePauseBarsRemaining--;

   if(!SessionAllowed())
   {
      LogShort(BotName + " | Session filter blocked new entry");
      return;
   }

   double swingHigh = 0.0;
   double swingLow = 0.0;
   bool swingHighFound = FindSwingHigh(rates, bars, swingHigh);
   bool swingLowFound = FindSwingLow(rates, bars, swingLow);

   int h1 = HTFBias(hH1Fast, hH1Slow, BiasTF1);
   int h4 = HTFBias(hH4Fast, hH4Slow, BiasTF2);
   int netBias = 0;
   if(h1 == DIR_BUY && h4 == DIR_BUY) netBias = DIR_BUY;
   if(h1 == DIR_SELL && h4 == DIR_SELL) netBias = DIR_SELL;

   double lastClose = rates[1].close;

   double guardATR = Buf(hATR, 0, 1);
   string guardReason = "";
   if(SpikeGuardActive(rates, bars, guardATR, guardReason))
   {
      LogShort(BotName + " | Entry blocked by spike guard | " + guardReason);
      return;
   }

   bool currBuyStruct = false;
   bool currSellStruct = false;
   string currBuyStructName = "";
   string currSellStructName = "";
   double currBuyLevel = 0.0;
   double currSellLevel = 0.0;

   if(swingHighFound && lastClose > swingHigh)
   {
      currBuyStruct = true;
      currBuyLevel = swingHigh;
      currBuyStructName = (netBias == DIR_SELL) ? "Current bullish MSS/CHOCH" : "Current bullish BOS";

      if(UseMemoryEngine)
      {
         memBuyStruct = true;
         memBuyLevel = currBuyLevel;
         memBuyStructAge = 0;
         memBuyStructType = currBuyStructName;
      }
   }

   if(swingLowFound && lastClose < swingLow)
   {
      currSellStruct = true;
      currSellLevel = swingLow;
      currSellStructName = (netBias == DIR_BUY) ? "Current bearish MSS/CHOCH" : "Current bearish BOS";

      if(UseMemoryEngine)
      {
         memSellStruct = true;
         memSellLevel = currSellLevel;
         memSellStructAge = 0;
         memSellStructType = currSellStructName;
      }
   }

   double prevHigh = HighestHigh(rates, bars, 2, SweepLookback);
   double prevLow  = LowestLow(rates, bars, 2, SweepLookback);

   bool currBuySweep = false;
   bool currSellSweep = false;
   double currBuySweepExtreme = 0.0;
   double currSellSweepExtreme = 0.0;

   if(prevLow > 0 && rates[1].low < prevLow && rates[1].close > prevLow)
   {
      currBuySweep = true;
      currBuySweepExtreme = rates[1].low;

      if(UseMemoryEngine)
      {
         memBuySweep = true;
         memBuySweepLow = currBuySweepExtreme;
         memBuySweepAge = 0;
      }
   }

   if(prevHigh > 0 && rates[1].high > prevHigh && rates[1].close < prevHigh)
   {
      currSellSweep = true;
      currSellSweepExtreme = rates[1].high;

      if(UseMemoryEngine)
      {
         memSellSweep = true;
         memSellSweepHigh = currSellSweepExtreme;
         memSellSweepAge = 0;
      }
   }

   double buyFvgL = 0.0, buyFvgM = 0.0, buyFvgU = 0.0;
   double sellFvgL = 0.0, sellFvgM = 0.0, sellFvgU = 0.0;
   bool currBuyFVG = FindFVG(rates, bars, DIR_BUY, buyFvgL, buyFvgM, buyFvgU);
   bool currSellFVG = FindFVG(rates, bars, DIR_SELL, sellFvgL, sellFvgM, sellFvgU);

   if(UseMemoryEngine && currBuyFVG)
   {
      memBuyFVG = true;
      memBuyFvgLower = buyFvgL;
      memBuyFvgMid = buyFvgM;
      memBuyFvgUpper = buyFvgU;
      memBuyFvgAge = 0;
   }

   if(UseMemoryEngine && currSellFVG)
   {
      memSellFVG = true;
      memSellFvgLower = sellFvgL;
      memSellFvgMid = sellFvgM;
      memSellFvgUpper = sellFvgU;
      memSellFvgAge = 0;
   }

   Signal buySig = BuildSignal(
      DIR_BUY,
      currBuyStruct,
      currBuyLevel,
      currBuyStructName,
      currBuySweep,
      currBuySweepExtreme,
      currBuyFVG,
      buyFvgL,
      buyFvgM,
      buyFvgU,
      swingHighFound,
      swingHigh,
      swingLowFound,
      swingLow
   );

   Signal sellSig = BuildSignal(
      DIR_SELL,
      currSellStruct,
      currSellLevel,
      currSellStructName,
      currSellSweep,
      currSellSweepExtreme,
      currSellFVG,
      sellFvgL,
      sellFvgM,
      sellFvgU,
      swingHighFound,
      swingHigh,
      swingLowFound,
      swingLow
   );

   PrintMemory();
   PrintSignal(buySig);
   PrintSignal(sellSig);

   int existingDir = 0;
   bool existingMixed = false;
   int existingCount = CountBotPositions(existingDir, existingMixed);
   if(existingCount > 0 && !existingMixed)
   {
      bool closed = false;
      if(existingDir == DIR_BUY)
         closed = CloseProfitablePositionsOnOppositeSignal(DIR_BUY, sellSig);
      else if(existingDir == DIR_SELL)
         closed = CloseProfitablePositionsOnOppositeSignal(DIR_SELL, buySig);

      if(closed)
      {
         LogShort(BotName + " | New entries paused this bar after Smart Early Exit");
         return;
      }
   }

   if(buySig.canTrade && sellSig.canTrade)
   {
      if(buySig.score > sellSig.score)
      {
         LogShort(BotName + " | Final decision: BUY chosen");
         ExecuteTrade(buySig);
      }
      else if(sellSig.score > buySig.score)
      {
         LogShort(BotName + " | Final decision: SELL chosen");
         ExecuteTrade(sellSig);
      }
      else
      {
         LogShort(BotName + " | Final decision: no trade because scores are equal");
      }
      return;
   }

   if(buySig.canTrade)
   {
      LogShort(BotName + " | Final decision: BUY accepted");
      ExecuteTrade(buySig);
      return;
   }

   if(sellSig.canTrade)
   {
      LogShort(BotName + " | Final decision: SELL accepted");
      ExecuteTrade(sellSig);
      return;
   }

   if(HeavyDebugLogs)
      Print(BotName + " | Final decision: no trade | BuySkip=" + buySig.skip + " | SellSkip=" + sellSig.skip);
}

//+------------------------------------------------------------------+
//| Init / Deinit / Tick                                             |
//+------------------------------------------------------------------+
int OnInit()
{
   Print(BotName + " started on " + _Symbol + " timeframe " + EnumToString(_Period));

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);

   hEmaFast = iMA(_Symbol, _Period, EMA_Fast, 0, MODE_EMA, PRICE_CLOSE);
   hEmaSlow = iMA(_Symbol, _Period, EMA_Slow, 0, MODE_EMA, PRICE_CLOSE);
   hRSI     = iRSI(_Symbol, _Period, RSI_Period, PRICE_CLOSE);
   hADX     = iADX(_Symbol, _Period, ADX_Period);
   hATR     = iATR(_Symbol, _Period, ATR_Period);

   hH1Fast  = iMA(_Symbol, BiasTF1, EMA_Fast, 0, MODE_EMA, PRICE_CLOSE);
   hH1Slow  = iMA(_Symbol, BiasTF1, EMA_Slow, 0, MODE_EMA, PRICE_CLOSE);
   hH4Fast  = iMA(_Symbol, BiasTF2, EMA_Fast, 0, MODE_EMA, PRICE_CLOSE);
   hH4Slow  = iMA(_Symbol, BiasTF2, EMA_Slow, 0, MODE_EMA, PRICE_CLOSE);

   if(hEmaFast == INVALID_HANDLE || hEmaSlow == INVALID_HANDLE || hRSI == INVALID_HANDLE ||
      hADX == INVALID_HANDLE || hATR == INVALID_HANDLE || hH1Fast == INVALID_HANDLE ||
      hH1Slow == INVALID_HANDLE || hH4Fast == INVALID_HANDLE || hH4Slow == INVALID_HANDLE)
   {
      Print(BotName + " | INIT FAILED: indicator handle error. LastError=" + IntegerToString(GetLastError()));
      return INIT_FAILED;
   }

   string log = BotName;
   log += " | INIT OK";
   log += " | Magic=" + IntegerToString((int)MagicNumber);
   log += " | BaseLot=" + DoubleToString(SymbolBaseLot(), 2);
   log += " | UseRiskPercent=" + B(UseRiskPercent);
   log += " | RiskPercent=" + DoubleToString(RiskPercent, 2);
   log += " | MinimumScore=" + IntegerToString(MinimumScore);
   log += " | RiskReward=" + DoubleToString(RiskReward, 2);
   log += " | BE=" + B(MoveToBreakEven);
   log += " | Trailing=" + B(EnableTrailingAfterBE);
   log += " | ProfitLock=" + B(UseProfitLock);
   log += " | TPRunner=" + B(UseTPRunner);
   log += " | LateEntryGuard=" + B(UseLateEntryGuard);
   log += " | SmartAddOns=" + B(AllowSmartAddOns);
   log += " | SpikeGuard=" + B(UseNewsSpikeGuard);
   log += " | SmartEarlyExit=" + B(UseSmartEarlyExit);
   log += " | MemoryEngine=" + B(UseMemoryEngine);
   log += " | No max trades/day";
   log += " | No daily loss stop";
   Print(log);

   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hEmaFast != INVALID_HANDLE) IndicatorRelease(hEmaFast);
   if(hEmaSlow != INVALID_HANDLE) IndicatorRelease(hEmaSlow);
   if(hRSI     != INVALID_HANDLE) IndicatorRelease(hRSI);
   if(hADX     != INVALID_HANDLE) IndicatorRelease(hADX);
   if(hATR     != INVALID_HANDLE) IndicatorRelease(hATR);
   if(hH1Fast  != INVALID_HANDLE) IndicatorRelease(hH1Fast);
   if(hH1Slow  != INVALID_HANDLE) IndicatorRelease(hH1Slow);
   if(hH4Fast  != INVALID_HANDLE) IndicatorRelease(hH4Fast);
   if(hH4Slow  != INVALID_HANDLE) IndicatorRelease(hH4Slow);

   Print(BotName + " stopped on " + _Symbol + " reason=" + IntegerToString(reason));
}

void OnTick()
{
   ManageOpenPositions();

   if(!EvaluateEveryTick)
   {
      if(!IsNewBar()) return;
   }

   EvaluateSignals();
}
//+------------------------------------------------------------------+
